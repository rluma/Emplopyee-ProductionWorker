﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_and_ProductionWorker
{
    public partial class Form1 : Form
    {
        ProductionWorker pdWorker = new ProductionWorker();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try 
            {
                pdWorker.Name = nameTextBox.Text;
                pdWorker.Number = int.Parse(numberTextBox.Text);
                pdWorker.HourlyRate = decimal.Parse(payRateTextBox.Text);
                outputLabel.Text = "Employee Name: " + pdWorker.Name + "\n" +
                                "Employee Number: " + pdWorker.Number + "\n" +
                                "Shift Number: " + pdWorker.ShiftNum + "\n" +
                                "Hourly pay rate: " + pdWorker.HourlyRate.ToString("c");
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void nightRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (nightRadioButton.Checked)
            {
                pdWorker.ShiftNum = 2;
            }
        }

        private void dayRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (dayRadioButton.Checked)
            {
                pdWorker.ShiftNum = 1;
            }
        }
    }
}

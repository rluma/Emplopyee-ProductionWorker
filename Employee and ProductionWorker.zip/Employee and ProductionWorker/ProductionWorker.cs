﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker
{
    class ProductionWorker : Employee
    {
        public int ShiftNum { get; set; }
        public decimal HourlyRate { get; set; }
    }
}
